import { createContext } from "react";

export const usercontext = createContext({
    point:false
})
export const datacontext  = createContext({
    data:""
})